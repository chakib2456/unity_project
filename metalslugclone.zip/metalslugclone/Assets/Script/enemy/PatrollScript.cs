﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PatrollScript : MonoBehaviour {

	public PatrolEnemy pl;
	float negaspeed;
	float speed;
	
	 void OnTriggerEnter2D (Collider2D col)
    {
	 	speed = -pl.speed;
	 	negaspeed = -pl.speed;
	 	if(col.gameObject.tag == "PtR" && pl.alert == false){
	 		Debug.Log("heat");
	 		
	 		pl.speed = negaspeed;
	 		pl.transform.localScale = new Vector2 (-5,5);
	 		
	 	}
	 	
	 	if(col.gameObject.tag == "PtL" && pl.alert == false){
	 		Debug.Log("heat");
	 		
	 		pl.speed = speed;
	 		pl.transform.localScale = new Vector2 (5,5);
	 		
	 	}
	 }
}
