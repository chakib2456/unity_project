﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PatrolEnemy : MonoBehaviour {

	public float speed ;
	public Transform target;
	public float maxdistance;
	public Transform player;
	public GameObject pl;
	public bool alert = false;
	bool isTracking = true;
	Animator anime;
	
	void Awake () {
		
		anime = GetComponent<Animator>();
		target = GameObject.FindGameObjectWithTag ("Player").transform;
		pl = GameObject.FindGameObjectWithTag ("Player");
		player = GetComponent<Transform>();
		
	}
	
	
	
	void Update () {
		
		anime.SetFloat("speed",speed);
		
		/*if(isTracking == false){
		move_enemy();
		}*/
			Track();
		
	}
	
	void move_enemy(){
		
		transform.position += Vector3.right * speed * Time.deltaTime;
	}
	
	void Track(){
		if(Vector2.Distance(target.position,player.position)<=maxdistance ){
			transform.position =  Vector2.MoveTowards(transform.position,target.position,speed*Time.deltaTime);
			alert = true;
			isTracking = true;
			Debug.Log("vv");
		}
		
		
	}


}
