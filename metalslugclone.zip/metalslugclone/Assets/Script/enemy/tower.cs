﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class tower : MonoBehaviour {

	
	public PatrolEnemy PE;
	
	
	
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		if (PE.alert == true){
			Debug.Log("shot");
		}
	}
}
